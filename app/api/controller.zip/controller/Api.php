<?php
namespace app\api\controller;
use core\Controller;
use core\Model;
use core\Session;

class Api extends Controller
{
    protected $db_config;
    protected $module='admin';
 function __construct()
 {
     $this->db_config = include (APP_PATH . DS . $this->module . DS . 'config.php');
     
 }
 /**
  * 获取model
  *
  * @param string $name
  * @return Model
  */
 protected function getModel($name)
 {
     $name = ucfirst(trim($name));
     $key = md5($name);
     if (isset($this->model[$key]))
         return $this->model[$key];
         else {
             $model = "\\app\\admin\\model\\" . $name;
             return $this->model[$key] = new $model($this->db_config);
         }
 }
 protected function getConfig()
 {
     return $this->getModel('config')->get(1, 'id');
 }
 protected function getUploadImg()
 {
     return Session::get('uploadImg')?:$this->getConfig()[0]->uploadImg;
 }
}