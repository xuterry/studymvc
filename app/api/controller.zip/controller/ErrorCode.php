<?php
namespace app\api\controller;
use core\Request;
use core\Session;

class ErrorCode extends Api
{

    function __construct()
    {
        parent::__construct();
    }
}