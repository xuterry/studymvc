<?php
namespace app\api\controller;
use core\Request;
use core\Session;

class Plugs extends Api
{

    function __construct()
    {
        parent::__construct();
    }
    private  function pay()
    {
        echo "string";
    }

}