<?php
namespace app\api\controller;
use core\Request;
use core\Session;

class Upgrade extends Api
{

    function __construct()
    {
        parent::__construct();
    }
}